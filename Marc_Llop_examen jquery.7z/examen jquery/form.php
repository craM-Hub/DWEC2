<?php
echo $_GET["nombre"] . 'recibirás en brece información al correo' . $_GET["correo"];